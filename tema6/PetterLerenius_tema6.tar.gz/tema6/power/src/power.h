//pray to cthulhu this helps

#ifndef POWER_H
#define POWER_H

float calc_power_r(float volt, float resistance);
float calc_power_i(float current, float resistance);

#endif
